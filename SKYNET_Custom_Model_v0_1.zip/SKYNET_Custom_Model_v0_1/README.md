# SKYNET Custom Model v0.1

This project trains a small decoder-only Transformer **from scratch**.
It does not load Qwen/Llama weights.

Important:
- v0.1 is a learning + training foundation.
- Training is intended for a GPU/Colab environment.
- Android/Termux will be used later for inference/quantization.
- The model is intentionally small; quality depends heavily on the dataset and training compute.

## Architecture

Tokenizer -> token embeddings -> positional embeddings -> Transformer decoder blocks -> LM head

Default target:
- vocab: 16,000
- context: 512
- layers: 6
- hidden size: 256
- attention heads: 8
- feed-forward size: 1024

This is a small model suitable for learning and experimentation, not a ChatGPT-scale model.

## 1. Install

```bash
pip install -r requirements.txt
```

For a CUDA machine, install the appropriate PyTorch build from pytorch.org first.

## 2. Prepare data

Put training text files in `data/raw/`, then run:

```bash
python src/prepare_data.py
```

The prepared dataset is written to `data/train.bin` and `data/val.bin`.

For the first experiment, use clean text/code rather than random scraped data.

## 3. Train

```bash
python src/train.py --config configs/small.json
```

The script automatically resumes from the latest checkpoint when available.

## 4. Generate text

```bash
python src/generate.py --checkpoint checkpoints/latest.pt --prompt "def hello"
```

## Important next phase

After v0.1 learns the basic training pipeline, we will add:
1. instruction/chat dataset format
2. code-specialized dataset
3. better tokenizer
4. evaluation set
5. tool/function-calling format
6. a llama.cpp/GGUF-compatible architecture/export path
7. SKYNET file tools, memory and voice outside the model
